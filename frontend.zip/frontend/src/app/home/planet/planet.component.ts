import { Component, OnInit } from '@angular/core';
import { PersonajesService } from "../../Services/personajes.service";
import { PlanetasService } from "../../Services/PlanetasService";
import {MatGridListModule} from '@angular/material/grid-list';
import {MatCardModule} from '@angular/material/card';

@Component({
  selector: 'app-planet',
  templateUrl: './planet.component.html',
  styleUrls: ['./planet.component.css']
})
export class PlanetComponent implements OnInit { 
  
  Personajes: any = {};  
  Planetas: any = {};
  Data: any = {}
  persona: string = "prueba"
  
  constructor( 
    private _Personajes: PersonajesService,
    private _Planetas: PlanetasService    
    ) { 
  }

  ngOnInit(): void {
    this._Planetas.getPlanet().subscribe( res => {
      this.Data = res;
      this.Personajes = res.results;
      //prueba
      console.log(this.Data)
    })
  }

  paginacion1(){   
    if(this.Data.previous != "null"){
      this._Planetas.getPlanet2(this.Data.previous).subscribe( res => {
        this.Data = res;
        this.Personajes = res.results;
        //prueba
        console.log(this.Data)
      })
      }
  }

  paginacion2(){
    if(this.Data.next != "null"){
    this._Planetas.getPlanet2(this.Data.next).subscribe( res => {
      this.Data = res;
      this.Personajes = res.results;
      //prueba
      console.log(this.Data)
    })
    }
  }

  personaje(Url: string){
    this._Personajes.getAPeople(Url).subscribe( res => {
      
      this.persona = res.name;
      this.persona = "prueba"      
      //prueba
      console.log(this.persona)
    })
    }
  

}
