import { Component, OnInit } from '@angular/core';
import { PersonajesService } from "../../Services/personajes.service";
import {MatGridListModule} from '@angular/material/grid-list';
import {MatCardModule} from '@angular/material/card';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  
  Personajes: any = {};  
  Planetas: any = {};
  Data: any = {}
  
  constructor( private _Personajes: PersonajesService) { 
  }

  ngOnInit(): void {
    this._Personajes.getAllPeople().subscribe( res => {
      this.Data = res;
      this.Personajes = res.results;
      //prueba
      console.log(this.Data)
    })
  }

  paginacion1(){   
    if(this.Data.previous != "null"){
      this._Personajes.getAllPeople2(this.Data.previous).subscribe( res => {
        this.Data = res;
        this.Personajes = res.results;
        //prueba
        console.log(this.Data)
      })
      }
  }

  paginacion2(){
    if(this.Data.next != "null"){
    this._Personajes.getAllPeople2(this.Data.next).subscribe( res => {
      this.Data = res;
      this.Personajes = res.results;
      //prueba
      console.log(this.Data)
    })
    }
  }

  

}
