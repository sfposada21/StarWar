import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HeaderComponent } from './home/header/header.component';
import { FooterComponent } from './home/footer/footer.component';
import { LoginComponent } from './home/login/login.component';

import { PlanetComponent } from './home/planet/planet.component';


const routes: Routes = [  
  {    path: '',    component: LoginComponent,    pathMatch: 'full',  },  
  {    path: 'planet',    component: PlanetComponent,    pathMatch: 'full',  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
