import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class PersonajesService {

  private API_PERSONAES = "https://swapi.dev/api/people/"
  private API_PERSONAES2 = ""
  
  

  constructor(private http: HttpClient) { }

  public getAllPeople(): Observable<any>{    
    return this.http.get(this.API_PERSONAES);
    }

  public getAllPeople2(API_PERSONAES2: string): Observable<any>{    
    return this.http.get(API_PERSONAES2);
    }
  
  public getAPeople( id: any): Observable<any>{    
    return this.http.get(id);
    }

}
