import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from "rxjs";


@Injectable({
  providedIn: 'root'
})
export class PlanetasService {

  private API_PLANET = "https://swapi.dev/api/planets";
  private API_PLANET2 = "";


  constructor(private http: HttpClient) { }

  public getPlanet(): Observable<any> {
    return this.http.get(this.API_PLANET);
  }

  public getPlanet2(API_PLANET2: string): Observable<any> {
    return this.http.get(API_PLANET2);
  }

}
