const dropArea = document.querySelector(".drag-area");
const dragText = document.querySelector("h2");
const button = document.querySelector("button");
const input = document.querySelector("#input-file");
let files;

button.addEventListener("click", (e) => {
  input.click();
});

input.addEventListener("change", (e) => {
  files = this.files;
  dropArea.ClassList.add("active");
  showFiles(files);
  dropArea.ClassList.remove("active");
  console.log("prueba 1")
});

dropArea.addEventListener("dragover", (e)=>{
    e.preventDefault();
    dropArea.ClassList.add("active")
    dragText.textContent ="Suelta pra subir archivos"    
  console.log("prueba 2")
})

dropArea.addEventListener("dragleave", (e)=>{
    dropArea.ClassList.remove("active")
    dragText.textContent = "Arrasta y suelta documentos 2"    
  console.log("prueba 3")
})

dropArea.addEventListener("drop", (e)=>{    
    dropArea.ClassList.remove("active")   
    dragText.textContent = "Arrasta y suelta documentos 2"
})

function showFiles(files) {
  if (files.lenght == undefined) {
    process(files);
  } else {
    for (const file of files) {
      processFile(file);
    }
  }
}
